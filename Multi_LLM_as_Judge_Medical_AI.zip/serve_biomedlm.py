import os, torch
from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForCausalLM
import uvicorn

HF_CACHE  = os.environ.get("HF_HOME", "/lustre/smuexa01/client/users/mkotha/CS7325/hf_models")
MODEL_ID  = "stanford-crfm/BioMedLM"
DEVICE    = "cuda" if torch.cuda.is_available() else "cpu"

print(f"Loading BioMedLM on {DEVICE} ...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, cache_dir=HF_CACHE)
model     = AutoModelForCausalLM.from_pretrained(MODEL_ID, cache_dir=HF_CACHE,
                torch_dtype=torch.bfloat16 if DEVICE=="cuda" else torch.float32)
model     = model.to(DEVICE)
model.eval()
print("BioMedLM loaded.")

app = FastAPI()

class ChatRequest(BaseModel):
    model: str = MODEL_ID
    messages: list
    max_tokens: int = 512
    temperature: float = 0.0

@app.post("/v1/chat/completions")
def chat(req: ChatRequest):
    # FIX: merge all messages so system rubric instructions are not dropped
    parts = []
    for m in req.messages:
        role = m.get("role", "user").upper()
        parts.append(f"[{role}]\n{m['content']}") 
    prompt  = "\n\n".join(parts)
    inputs  = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=1536).to(DEVICE)
    in_len  = inputs["input_ids"].shape[1]
    max_new = min(req.max_tokens, 512)
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens = max_new,
            pad_token_id   = tokenizer.eos_token_id,
            do_sample      = req.temperature > 0,
            temperature    = req.temperature if req.temperature > 0 else 1.0,
        )
    text = tokenizer.decode(out[0][in_len:], skip_special_tokens=True)
    return {
        "id": "biomedlm", "object": "chat.completion", "model": MODEL_ID,
        "choices": [{"index": 0,
            "message": {"role": "assistant", "content": text},
            "finish_reason": "stop"}],
        "usage": {"prompt_tokens": in_len,
                  "completion_tokens": len(out[0])-in_len,
                  "total_tokens": len(out[0])}
    }

@app.get("/health")
def health(): return {"status": "ok"}

@app.get("/v1/models")
def models(): return {"data": [{"id": MODEL_ID}]}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8004)