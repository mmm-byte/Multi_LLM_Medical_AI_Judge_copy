# Multi-LLM-as-Judge: Medical AI Evaluation (ADRD Focus)

> **EMNLP 2026 Research Repository** — Evaluating inter-judge agreement of small medical LLMs on ADRD caregiving QA using four complete, published rubric instruments from respected medical AI benchmarks.

[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)
[![EMNLP 2026](https://img.shields.io/badge/Venue-EMNLP%202026-green)]()

This repository is the **paper-aligned research codebase** for:

> **"Multi-LLM-as-Judge for ADRD Medical QA: Rubric Sensitivity and Small-Model Agreement in Privacy-Safe Clinical Evaluation"**
> *Mahindra Guptha Kotha — EMNLP 2026 (under review)*

Companion general-purpose framework: [Multi-LLMs-as-Judge](https://github.com/m22oct2000/Multi-LLMs-as-Judge)

---

## Research Overview

Large cloud-based LLM judges are impractical for medical AI because patient data is private and sensitive. Small models (≤7B parameters) deployable locally on HPC or edge devices are the practical target for real-world clinical NLP. This paper asks:

> *Can 3–4 small, medical-domain LLMs reliably agree when evaluating ADRD caregiving answers — and does the choice of a complete, published rubric instrument change that agreement?*

**Three core research questions:**

| # | Research Question |
|---|---|
| RQ1 | Do small medical LLMs agree with each other when judging ADRD answers under complete published rubrics? |
| RQ2 | Which published rubric instrument produces the most stable inter-judge agreement — and which produces the most disagreement? |
| RQ3 | Does agreement vary across ADRD question categories (clinical knowledge vs. caregiving vs. safety-critical vs. behavioral)? |

**Key design decisions:**
- ✅ **No mediator** — output is agreement analysis only, not answer correction
- ✅ **Small models only (≤7B)** — privacy-safe, deployable on HPC/local devices
- ✅ **3–4 judges** — sufficient panel size, no diminishing returns overhead
- ✅ **One complete rubric instrument per paper** — the entire rubric is taken from one paper and applied as-is; no mixing criteria across papers
- ✅ **ADRD-Bench questions** — domain-specific caregiving QA, not generic medical trivia
- ✅ **All LLM rationales printed** — user can inspect full reasoning per judge per rubric
- ✅ **PNG figures** for all results → upload directly to Overleaf
- ✅ **Box plots** per category per judge for agreement score distributions

---

## The 4 Rubrics — One Complete Instrument Per Paper

Each rubric is taken **whole** from a single published paper. No criteria are mixed across papers. Justification is simple: *"We used Rubric X exactly as defined in Paper Y, without modification."*

The evaluation pipeline runs **once per rubric** — same questions, same judges, different rubric — and results are compared across rubrics.

```
ADRD Question → 3–4 Small Medical LLM Judges
                        ↓
    [Rubric 1: Full PEMAT]              → Agreement scores → Box plot → Correlation table
    [Rubric 2: Full HealthBench]        → Agreement scores → Box plot → Correlation table
    [Rubric 3: Full Clinical LLM Eval]  → Agreement scores → Box plot → Correlation table
    [Rubric 4: Full Prometheus]         → Agreement scores → Box plot → Correlation table
```

---

### Rubric 1 — PEMAT (Patient Education Materials Assessment Tool)
**Paper:** Shoemaker SJ, Wolf MS, Brach C. *"Development of the PEMAT, a new measure of understandability and actionability for print and audiovisual patient information."* Patient Education and Counseling, 2014. PMID 24973195. [AHRQ](https://www.ahrq.gov/pemat)

**What the full rubric covers:**
- **Understandability** (19 items): common everyday language, active voice, logical sequence, avoidance of jargon, use of visual cues, chunked information, informative headers
- **Actionability** (7 items): identifies at least one action the user can take, addresses user directly, breaks actions into explicit steps, provides tangible tools

**Why for ADRD:** ADRD caregiving answers are read by family caregivers with varying health literacy — not clinicians. PEMAT was specifically designed for patient-facing health materials and validated with consumers of diverse backgrounds. The inter-rater reliability (Gwet's AC1 = 0.74) and strong internal consistency (Cronbach's α = 0.71) make it a robust published standard.

**Scale:** BINARY (0 = disagree, 1 = agree) per item; final score = sum / total possible × 100

---

### Rubric 2 — HealthBench
**Paper:** Arora et al. *"HealthBench: Evaluating Large Language Models Towards Better Human Health."* OpenAI, 2025. [openai.com/index/healthbench](https://openai.com/index/healthbench/)

**What the full rubric covers:**
- Physician-written binary criteria per conversation: facts to include, harmful advice to avoid, emergency escalation requirements, contraindication identification, appropriate uncertainty expression
- Criteria are weighted by physician-judged clinical importance
- Organized across: Communication (clear, actionable), Medical correctness, Safety (no harmful omissions), Emergency referral

**Why for ADRD:** HealthBench is the most comprehensive published rubric for evaluating LLM medical responses, built by OpenAI with practicing physicians. Applying it to ADRD answers directly connects this work to the most cited medical LLM evaluation standard.

**Scale:** BINARY (0/1) per criterion; final score = weighted sum of satisfied criteria

---

### Rubric 3 — Clinical LLM Evaluation by Expert Review
**Paper:** *"Clinical Large Language Model Evaluation by Expert Review."* PMC 2025. [pmc.ncbi.nlm.nih.gov/articles/PMC12677871](https://pmc.ncbi.nlm.nih.gov/articles/PMC12677871/)

**What the full rubric covers:**
- **Medical Accuracy** (30% weight): factual correctness against clinical guidelines
- **Safety** (25% weight): no harmful advice, correct contraindications, appropriate escalation
- **Clinical Relevance** (20% weight): meaningful and useful in clinical context, addresses real clinical issues
- **Completeness** (15% weight): covers all aspects of the question without significant omission
- **Clarity** (10% weight): clear, well-organized, understandable response

**Why for ADRD:** This rubric was developed and validated by expert physicians specifically for evaluating LLM responses in clinical QA settings. The weighted multi-dimensional structure directly maps onto ADRD caregiving assessment needs.

**Scale:** LIKERT 1–5 per dimension; final score = weighted average across dimensions

---

### Rubric 4 — Prometheus
**Paper:** Kim et al. *"Prometheus: Inducing Fine-Grained Evaluation Capability in Language Models."* ICLR 2024. [prometheus-eval/prometheus-eval](https://github.com/prometheus-eval/prometheus-eval)

**What the full rubric covers:**
- **Instruction Following**: does the response follow the given instructions and constraints?
- **Accuracy / Factual Correctness**: are the claims factually correct?
- **Coherence**: is the response logically structured and internally consistent?
- **Completeness**: does the response address all aspects of the prompt?
- Rubric-grounded scoring: judge is given the rubric definition and a reference answer before scoring

**Why for ADRD:** Prometheus is the most widely cited LLM-as-judge rubric in the NLP evaluation literature, enabling direct comparison with NLP community baselines. Applying it to ADRD answers situates this work within the broader LLM evaluation research community.

**Scale:** LIKERT 1–5 per dimension; final score = mean across dimensions

---

## The Judge Panel (≤7B Only)

All judges are small, medical-domain fine-tuned models deployable on HPC or local GPU. No cloud-only models — patient data stays private.

| Judge | Size | Type | Deployment |
|---|---|---|---|
| MedGemma-4B-IT | 4B | Medical fine-tuned (Google DeepMind) | Local vLLM / HPC |
| BioMistral-7B | 7B | Medical fine-tuned (BioMedical corpus) | Local vLLM / HPC |
| Meditron-7B | 7B | Medical fine-tuned (EPFL) | Local vLLM / HPC |
| BioMedLM-7B or Llama-3.2-3B-Medical | 3–7B | Medical fine-tuned | Local vLLM / HPC |

> **3 judges minimum, 4 maximum.** All on HPC via vLLM.

---

## Benchmark Dataset (ADRD-Bench)

Questions sourced from **[ADRD-Bench](https://arxiv.org/abs/2602.11460)** (Zhao et al., 2026) — the first benchmark for Alzheimer's Disease and Related Dementias QA, including questions from the Aging Brain Care (ABC) program.

| Category | Description | # Questions (target) |
|---|---|---|
| Clinical Knowledge | Staging, diagnosis, biomarkers | ~20 |
| Caregiving Guidance | Daily care, behavioral management, caregiver support | ~20 |
| Safety-Critical | Medication safety, fall prevention, emergency signs | ~20 |
| Behavioral Management | Agitation, wandering, sundowning, communication | ~20 |

A **dataset table** with per-category counts, question formats, and sources is produced in Experiment 1.

---

## Agreement Classification

For each question evaluated by the judge panel, agreement is classified as:

| Class | Criteria | Meaning |
|---|---|---|
| **Fully Agree** | All judges within agreement threshold | Strong consensus |
| **Majority Agree** | 3 of 4 agree; 1 outlier | Near-consensus — outlier's rationale is highlighted |
| **Split** | 2 agree, 2 disagree | Rubric ambiguity signal |
| **Full Disagree** | All diverge | Rubric breakdown |

The **outlier judge** (the one that did not agree with others) is kept and its full rationale is printed — this is a key output of the paper, showing what a dissenting small model reasons differently about ADRD answers.

Pairwise agreement is computed per rubric. A correlation table across rubrics is produced one-by-one (not aggregated).

---

## Experiments

### Exp 1 — Dataset Analysis
- Categorize ADRD-Bench questions into 4 categories
- Produce dataset table (category, count, format, source guideline)
- Finalize question set used across all experiments

### Exp 2 — Per-Rubric Agreement Analysis *(Core Experiment)*
- Run all judges on all ADRD questions under each of the 4 complete rubrics
- Classify each question: Fully Agree / Majority Agree / Split / Full Disagree
- Compute pairwise agreement per rubric
- Print **all LLM rationales** for every judgment (per judge, per question, per rubric)
- Produce one agreement summary table per rubric
- Produce one pairwise correlation table across rubrics

### Exp 3 — Rubric Sensitivity
- For each of the 4 rubrics, test different scoring systems (BINARY, LIKERT 1–5, scaled 0–10)
- Measure which scoring system produces the most stable inter-judge agreement
- Ablation: if two rubric score distributions are too close → remove; if distinguishable → keep
- Each rubric cites only its source paper for scoring definitions

### Exp 4 — Cross-Category Agreement Box Plots
- For each question category × each judge: compute agreement score distribution across all questions in that category
- Plot a **box plot** (mean + median labeled)
- Output: one PNG box plot per rubric → upload to Overleaf
- Also produce 1–2 summary rubric output figures per rubric

---

## Repository Structure

```
Multi_LLM_as_Judge_Medical_AI/
│
├── core/                            # Framework (no mediator)
│   ├── wrapper.py                   # Simplified consensus scoring (no correction loop)
│   ├── rubric_engine.py             # Rubric parsing, LIKERT/BINARY scoring
│   ├── agreement.py                 # Pairwise agreement + classification logic
│   ├── schemas.py                   # Pydantic rubric schemas
│   └── consensus_core/              # Domain models
│
├── config/
│   ├── llm_client.py
│   ├── endpoint_config.py
│   └── configs/
│       ├── config_exp1_dataset.json
│       ├── config_exp2_agreement.json
│       ├── config_exp3_rubric_sensitivity.json
│       └── config_exp4_boxplots.json
│
├── benchmark_dataset/               # ADRD-Bench questions (renamed from benchmark/)
│   ├── adrd_questions.json          # Categorized ADRD questions
│   └── dataset_table.md             # Table: count per category
│
├── rubrics/                         # 4 complete rubric instruments (one per paper)
│   ├── rubric1_pemat.json           # Full PEMAT — Shoemaker et al. 2014
│   ├── rubric2_healthbench.json     # Full HealthBench — Arora et al. 2025
│   ├── rubric3_clinical_eval.json   # Full Clinical LLM Eval — PMC 2025
│   └── rubric4_prometheus.json      # Full Prometheus — Kim et al. 2024
│
├── prompts/                         # Per-model prompts for each rubric
│   ├── medgemma_prompt.txt
│   ├── biomistral_prompt.txt
│   ├── meditron_prompt.txt
│   └── llama_medical_prompt.txt
│
├── experiments/
│   ├── exp1_dataset_analysis.py
│   ├── exp2_agreement_analysis.py
│   ├── exp3_rubric_sensitivity.py
│   └── exp4_boxplot_agreement.py
│
├── results/
│   ├── exp1_dataset_table.json
│   ├── exp2_agreement_results.json
│   ├── exp3_sensitivity_results.json
│   ├── exp4_boxplot_data.json
│   └── figures/                     # PNG files → upload to Overleaf
│       ├── fig_exp2_agreement_rubric1_pemat.png
│       ├── fig_exp2_agreement_rubric2_healthbench.png
│       ├── fig_exp2_agreement_rubric3_clinical.png
│       ├── fig_exp2_agreement_rubric4_prometheus.png
│       ├── fig_exp3_rubric_sensitivity.png
│       └── fig_exp4_boxplot_by_category.png
│
├── paper/                           # EMNLP 2026 LaTeX
│   ├── paper.tex
│   ├── references.bib
│   ├── acl.sty
│   └── acl_natbib.bst
│
├── notebooks/
│   └── results_analysis.ipynb
│
├── tests/
├── requirements.txt
├── .env.example
└── README.md
```

---

## Step-by-Step Execution Plan

### Phase 1 — Setup
- [ ] 1. Pull ADRD-Bench questions from [HuggingFace](https://huggingface.co/datasets/IIRL-NotreDame/ADRD-Bench) and categorize into 4 groups
- [ ] 2. Create 4 rubric JSON files — one complete instrument per paper
- [ ] 3. Write per-model prompts for each rubric (with full rubric definition embedded in prompt)
- [ ] 4. Migrate `core/` from old repo (remove mediator engine, keep rubric engine + agreement logic)
- [ ] 5. Set up `.env` with HPC vLLM endpoints

### Phase 2 — Experiments (in this order)
- [ ] 6. Exp 1: Build and verify dataset table
- [ ] 7. Exp 2: Run agreement analysis — log all rationales per judge per rubric
- [ ] 8. Exp 3: Rubric sensitivity with different scoring systems
- [ ] 9. Exp 4: Generate box plots per category per judge → export PNG

### Phase 3 — Paper Update
- [ ] 10. Update `paper.tex` — remove mediation section; add 4-rubric section with full citations
- [ ] 11. Insert PNG figures into Overleaf
- [ ] 12. Update `references.bib` — add PEMAT, HealthBench, Clinical LLM Eval, Prometheus, ADRD-Bench
- [ ] 13. Update abstract and results tables with real experiment numbers
- [ ] 14. Professor review → submit

---

## Quick Setup

```bash
git clone https://github.com/m22oct2000/Multi_LLM_as_Judge_Medical_AI.git
cd Multi_LLM_as_Judge_Medical_AI
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Fill in HPC vLLM endpoint URLs in .env
```

### Start local vLLM judges (HPC node required)

```bash
vllm serve google/medgemma-4b-it --port 8001
vllm serve BioMistral/BioMistral-7B --port 8002
vllm serve epfl-llm/meditron-7b --port 8003
vllm serve your-fourth-model --port 8004
```

### Run experiments

```bash
python experiments/exp1_dataset_analysis.py
python experiments/exp2_agreement_analysis.py
python experiments/exp3_rubric_sensitivity.py
python experiments/exp4_boxplot_agreement.py
```

Results saved to `results/expN_*.json`. Figures saved as PNG to `results/figures/`.

---

## Rubric Paper References

| Rubric | Full Paper Citation |
|---|---|
| Rubric 1 — PEMAT | Shoemaker SJ, Wolf MS, Brach C. Development of the PEMAT. *Patient Educ Couns.* 2014. PMID 24973195. |
| Rubric 2 — HealthBench | Arora et al. HealthBench: Evaluating LLMs Towards Better Human Health. OpenAI, 2025. |
| Rubric 3 — Clinical LLM Eval | Clinical LLM Evaluation by Expert Review. *PMC*, 2025. PMC12677871. |
| Rubric 4 — Prometheus | Kim et al. Prometheus: Inducing Fine-Grained Evaluation Capability in Language Models. *ICLR*, 2024. |

---

## Citation

```bibtex
@inproceedings{kotha2026multijudge,
  author    = {Kotha, Mahindra Guptha},
  title     = {Multi-LLM-as-Judge for ADRD Medical QA: Rubric Sensitivity and
               Small-Model Agreement in Privacy-Safe Clinical Evaluation},
  booktitle = {Proceedings of EMNLP 2026},
  year      = {2026},
  url       = {https://github.com/m22oct2000/Multi_LLM_as_Judge_Medical_AI}
}
```

---

## License

Released under the [Apache 2.0 License](LICENSE). Free for personal, academic, and commercial use with attribution.

---

## Ethical Considerations

This repository is research infrastructure for evaluating clinical NLP systems. It does not provide, endorse, or validate medical advice. All benchmark questions use publicly available ADRD caregiving materials as reference. Any deployment in clinical settings must be validated against physician expert judgments and subjected to appropriate regulatory review.
