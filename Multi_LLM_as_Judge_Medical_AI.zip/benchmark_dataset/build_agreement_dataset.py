"""Build the agreement benchmark CSV.

Generates 3 questions per clinical domain x 5 domains = 15 rows.
Each row has a question + reference_answer kept under MAX_QA_TOKENS.
Rows exceeding the token budget are silently dropped so all 4 models
(including BioMedLM with 1024 ctx) can process them.

Token budget:
    MAX_QA_TOKENS = 200  (Q + A combined, ~4 chars/token)
    This leaves ~300 tokens for prompt overhead + 100-200 for model output,
    fitting the tightest model (BioMedLM, 1024 ctx total).

Outputs:
    benchmark_dataset/agreement_benchmark.csv
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT  = ROOT / 'benchmark_dataset' / 'agreement_benchmark.csv'

# Hard token limit: Q + A combined must fit here
MAX_QA_TOKENS = 200   # ~800 chars

# ---------------------------------------------------------------------------
# Benchmark rows  (question + reference_answer, deliberately short & crisp)
# Each answer is 1-3 sentences — the model evaluates THIS answer text.
# expected_class reflects what a panel of aligned judges should agree on.
# ---------------------------------------------------------------------------

ROWS = [
    # --- Cardiology (3) ---
    {
        'id': 'FU_00000', 'domain': 'Cardiology',
        'question': 'What is the first-line treatment for a STEMI?',
        'reference_answer': 'Primary PCI within 90 minutes of first medical contact. Give aspirin 325 mg, heparin, and clopidogrel. Call cath lab immediately.',
        'expected_class': 'fully_agree', 'source': 'ACC/AHA STEMI guidelines',
    },
    {
        'id': 'FU_00001', 'domain': 'Cardiology',
        'question': 'What are the initial steps for a patient with ACS chest pain?',
        'reference_answer': '12-lead ECG within 10 minutes. Aspirin 325 mg immediately. IV access and troponin. Oxygen only if SpO2 < 94%.',
        'expected_class': 'fully_agree', 'source': 'ACC/AHA ACS guidelines',
    },
    {
        'id': 'FU_00002', 'domain': 'Cardiology',
        'question': 'How should anticoagulation be managed in atrial fibrillation?',
        'reference_answer': 'Calculate CHA2DS2-VASc score. Start anticoagulation for score >= 2 in men, >= 3 in women. Prefer DOACs over warfarin.',
        'expected_class': 'fully_agree', 'source': 'ACC/AHA AFib guidelines',
    },
    # --- Pharmacology (3) ---
    {
        'id': 'FU_00003', 'domain': 'Pharmacology',
        'question': 'What are common drug interactions with warfarin?',
        'reference_answer': 'NSAIDs, antibiotics (especially fluoroquinolones), and antifungals increase bleeding risk. Monitor INR closely when adding any new drug.',
        'expected_class': 'fully_agree', 'source': 'Clinical pharmacology reference',
    },
    {
        'id': 'FU_00004', 'domain': 'Pharmacology',
        'question': 'How do you manage a patient with metformin and renal impairment?',
        'reference_answer': 'Hold metformin if eGFR < 30. Reduce dose for eGFR 30-45. Restart 48 hours after contrast procedures once renal function confirmed stable.',
        'expected_class': 'fully_agree', 'source': 'ADA diabetes guidelines',
    },
    {
        'id': 'FU_00005', 'domain': 'Pharmacology',
        'question': 'What is the treatment for opioid overdose?',
        'reference_answer': 'Naloxone 0.4-2 mg IV/IM/intranasal. Repeat every 2-3 minutes as needed. Monitor for re-sedation. Observe for at least 4-6 hours.',
        'expected_class': 'fully_agree', 'source': 'ACEP opioid guidelines',
    },
    # --- Neurology (3) ---
    {
        'id': 'FU_00006', 'domain': 'Neurology',
        'question': 'What is the time window for tPA in ischemic stroke?',
        'reference_answer': 'IV alteplase within 3-4.5 hours of symptom onset. Door-to-needle time under 60 minutes. Exclude hemorrhage with CT first.',
        'expected_class': 'fully_agree', 'source': 'AHA stroke guidelines',
    },
    {
        'id': 'FU_00007', 'domain': 'Neurology',
        'question': 'How do you manage status epilepticus?',
        'reference_answer': 'Lorazepam 0.1 mg/kg IV as first-line. If no IV, diazepam rectally or midazolam IM. Follow with fosphenytoin if seizures persist.',
        'expected_class': 'fully_agree', 'source': 'Neurocritical Care Society guidelines',
    },
    {
        'id': 'FU_00008', 'domain': 'Neurology',
        'question': 'What are early signs of Alzheimer disease?',
        'reference_answer': 'Short-term memory loss, difficulty with familiar tasks, language problems, disorientation to time and place. Refer for neuropsychological evaluation.',
        'expected_class': 'majority_agree', 'source': 'Alzheimer Association criteria',
    },
    # --- Pediatrics (3) ---
    {
        'id': 'FU_00009', 'domain': 'Pediatrics',
        'question': 'How do you treat febrile seizures in children?',
        'reference_answer': 'Most are self-limiting. Ensure airway. Diazepam rectally if > 5 minutes. Antipyretics for comfort. No routine anticonvulsant prophylaxis needed.',
        'expected_class': 'majority_agree', 'source': 'AAP febrile seizure guidelines',
    },
    {
        'id': 'FU_00010', 'domain': 'Pediatrics',
        'question': 'What is the first-line antibiotic for pediatric otitis media?',
        'reference_answer': 'Amoxicillin 80-90 mg/kg/day for 10 days in children under 2. Watchful waiting acceptable in mild cases in children over 2.',
        'expected_class': 'fully_agree', 'source': 'AAP otitis media guidelines',
    },
    {
        'id': 'FU_00011', 'domain': 'Pediatrics',
        'question': 'How do you assess dehydration in a pediatric patient?',
        'reference_answer': 'Mild: < 3% weight loss, normal exam. Moderate: 3-9%, dry mucosa, decreased turgor. Severe: > 9%, altered mental status, no tears. Rehydrate accordingly.',
        'expected_class': 'fully_agree', 'source': 'WHO/AAP dehydration guidelines',
    },
    # --- Emergency (3) ---
    {
        'id': 'FU_00012', 'domain': 'Emergency',
        'question': 'What is the initial management of anaphylaxis?',
        'reference_answer': 'Epinephrine 0.3-0.5 mg IM in anterolateral thigh immediately. Call 911. Lay patient flat with legs elevated. Give diphenhydramine and corticosteroids as adjuncts.',
        'expected_class': 'fully_agree', 'source': 'ACEP anaphylaxis guidelines',
    },
    {
        'id': 'FU_00013', 'domain': 'Emergency',
        'question': 'How do you manage a patient with suspected sepsis?',
        'reference_answer': 'Blood cultures x2 before antibiotics. Broad-spectrum antibiotics within 1 hour. 30 mL/kg crystalloid bolus for hypotension. Measure lactate.',
        'expected_class': 'fully_agree', 'source': 'Surviving Sepsis Campaign',
    },
    {
        'id': 'FU_00014', 'domain': 'Emergency',
        'question': 'What are the signs of tension pneumothorax and immediate treatment?',
        'reference_answer': 'Tracheal deviation, absent breath sounds, hypotension, distended neck veins. Immediate needle decompression at 2nd ICS midclavicular line. Do not wait for X-ray.',
        'expected_class': 'fully_agree', 'source': 'ATLS guidelines',
    },
]


def _token_est(text: str) -> int:
    return len(text) // 4


def main() -> None:
    passed, dropped = [], []
    for row in ROWS:
        q_tok = _token_est(row['question'])
        a_tok = _token_est(row['reference_answer'])
        total = q_tok + a_tok
        if total <= MAX_QA_TOKENS:
            passed.append(row)
        else:
            dropped.append((row['id'], total))
            print(f'[FILTER] Dropped {row["id"]} — {total} tokens > {MAX_QA_TOKENS} limit')

    fieldnames = ['id', 'domain', 'question', 'reference_answer',
                  'expected_class', 'source', 'observed_class', 'verified']

    # Preserve any existing observed_class / verified values if CSV already exists
    existing: dict = {}
    if OUT.exists():
        with open(OUT, encoding='utf-8') as f:
            for r in csv.DictReader(f):
                existing[r['id']] = {'observed_class': r.get('observed_class', ''),
                                     'verified': r.get('verified', '')}

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in passed:
            row['observed_class'] = existing.get(row['id'], {}).get('observed_class', '')
            row['verified']       = existing.get(row['id'], {}).get('verified', '')
            writer.writerow(row)

    print(f'\nBenchmark CSV written: {OUT}')
    print(f'  Rows written : {len(passed)}')
    print(f'  Rows dropped : {len(dropped)}')
    for iid, tok in dropped:
        print(f'    {iid}: {tok} tokens')
    print(f'  Token limit  : {MAX_QA_TOKENS} tokens per Q+A')

    # Token stats
    tots = [_token_est(r['question']) + _token_est(r['reference_answer']) for r in passed]
    if tots:
        print(f'  Min Q+A tokens: {min(tots)}')
        print(f'  Max Q+A tokens: {max(tots)}')
        print(f'  Avg Q+A tokens: {sum(tots)//len(tots)}')


if __name__ == '__main__':
    main()
