# ADRD-Bench Dataset

Questions sourced from **[ADRD-Bench](https://huggingface.co/datasets/IIRL-NotreDame/ADRD-Bench)** (Zhao et al., 2026).

## Categories

| Category | Description |
|---|---|
| `clinical_knowledge` | Staging, diagnosis, biomarkers, disease progression |
| `caregiving_guidance` | Daily care routines, caregiver support, ADL assistance |
| `safety_critical` | Medication safety, fall prevention, emergency signs, wandering |
| `behavioral_management` | Agitation, sundowning, communication strategies, repetitive behaviors |

## Files

- `adrd_questions.json` — Categorized questions with IDs, text, category, and source
- `dataset_table.md` — Summary table for paper

## How to Regenerate

Run `python experiments/exp1_dataset_analysis.py` to pull from HuggingFace and rebuild this dataset.
