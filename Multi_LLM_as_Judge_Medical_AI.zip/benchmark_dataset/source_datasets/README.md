# Source Datasets

Place the following CSV files in this directory before running Experiment 1.
All files are sourced from the companion repo:
**https://github.com/m22oct2000/Multi-LLMs-as-Judge**

| File to create here | Source path in old repo | Description |
|---|---|---|
| `MedQuAD_train.csv` | `dataset/MedQuAD/train.csv` | NIH Medical Question-Answer pairs |
| `MedDialog_validation.csv` | `dataset/MedDialog/validation.csv` | Patient-doctor dialogue validation set |
| `medical_meadow_health_advice.csv` | `dataset/medical_meadow_health_advice/medical_meadow_health_advice.csv` | Health advice instruction-response pairs |

## Copy Commands (HPC)

```bash
OLD_REPO=/path/to/Multi-LLMs-as-Judge
NEW_REPO=/path/to/Multi_LLM_as_Judge_Medical_AI

cp $OLD_REPO/dataset/MedQuAD/train.csv \
   $NEW_REPO/benchmark_dataset/source_datasets/MedQuAD_train.csv

cp $OLD_REPO/dataset/MedDialog/validation.csv \
   $NEW_REPO/benchmark_dataset/source_datasets/MedDialog_validation.csv

cp $OLD_REPO/dataset/medical_meadow_health_advice/medical_meadow_health_advice.csv \
   $NEW_REPO/benchmark_dataset/source_datasets/medical_meadow_health_advice.csv
```

## What happens after copying

Exp 1 will automatically:
1. Load all three CSVs
2. Filter rows for ADRD-relevant questions using keyword matching
3. Classify each question into one of 4 categories:
   - `safety_critical`
   - `clinical_knowledge`
   - `behavioral_management`
   - `caregiving_guidance`
4. Save up to 50 questions per source (150 total max) to `benchmark_dataset/adrd_questions.json`

## Fallback

If no CSVs are found, the experiment falls back to 10 hand-written
placeholder questions so the rest of the pipeline can still run for development.

## Dataset Citations

- **MedQuAD**: Ben Abacha A & Demner-Fushman D. A Question-Entailment Approach to Question Answering. *BMC Bioinformatics*. 2019.
- **MedDialog**: Zeng G et al. MedDialog: Large-scale Medical Dialogue Datasets. *EMNLP 2020*.
- **Medical Meadow Health Advice**: Han T et al. MedAlpaca — An Open-Source Collection of Medical Conversational AI Models. *arXiv 2023*.
