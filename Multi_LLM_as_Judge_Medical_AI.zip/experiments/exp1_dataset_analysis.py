"""Experiment 1: Structured Multi-Domain Medical Benchmark Construction.

Builds a structured benchmark table from three source datasets:
  1. MedQuAD        (NIH medical QA pairs)
  2. MedDialog      (patient-doctor dialogue turns)
  3. Medical Meadow Health Advice (health advice instruction-response pairs)

All sourced from: https://github.com/m22oct2000/Multi-LLMs-as-Judge

Domains and representative question summaries:
  +---------------+----------------------------------------------------------+
  | Domain        | Question Summary                                         |
  +---------------+----------------------------------------------------------+
  | Cardiology    | STEMI management, 65-year-old, inferior ST elevation     |
  | Pharmacology  | Metformin contraindications and renal safety criteria    |
  | Neurology     | Thunderclap headache workup, SAH rule-out protocol       |
  | Pediatrics    | 2-month vaccination schedule, US CDC ACIP guidelines     |
  | Emergency     | BLS protocol, unresponsive non-breathing patient         |
  +---------------+----------------------------------------------------------+

Setup (copy CSVs from old repo before running):
    cp <old_repo>/dataset/MedQuAD/train.csv \
       benchmark_dataset/source_datasets/MedQuAD_train.csv
    cp <old_repo>/dataset/MedDialog/validation.csv \
       benchmark_dataset/source_datasets/MedDialog_validation.csv
    cp <old_repo>/dataset/medical_meadow_health_advice/medical_meadow_health_advice.csv \
       benchmark_dataset/source_datasets/medical_meadow_health_advice.csv

Run:
    python experiments/exp1_dataset_analysis.py

Outputs:
    benchmark_dataset/adrd_questions.json
    benchmark_dataset/dataset_table.md
    results/exp1_dataset_table.json
"""
from __future__ import annotations

import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

CONFIG_PATH = ROOT / "config" / "configs" / "config_exp1_dataset.json"
DATA_DIR    = ROOT / "benchmark_dataset" / "source_datasets"
MEDQUAD_CSV  = DATA_DIR / "MedQuAD_train.csv"
MEDDIALOG_CSV = DATA_DIR / "MedDialog_validation.csv"
MEDMEADOW_CSV = DATA_DIR / "medical_meadow_health_advice.csv"

# ---------------------------------------------------------------------------
# Domain definitions
# Each domain has:
#   keywords     : used to classify questions from datasets
#   summary      : short human-readable summary shown in the benchmark table
#   example_q    : representative question shown in the benchmark table
# ---------------------------------------------------------------------------
DOMAIN_DEFINITIONS: Dict[str, Dict] = {
    "Cardiology": {
        "keywords": [
            "stemi", "heart attack", "myocardial infarction", "mi ",
            "st elevation", "cardiac", "coronary", "angina", "pci",
            "troponin", "ecg", "ekg", "arrhythmia", "atrial fibrillation",
            "heart failure", "cardiology", "cardiomyopathy", "pericarditis",
            "aortic", "valve", "stent", "thrombolysis", "anti-platelet",
        ],
        "summary": "STEMI management, 65-year-old, inferior ST elevation",
        "example_q": "A 65-year-old presents with inferior ST elevation. What is the management?",
    },
    "Pharmacology": {
        "keywords": [
            "metformin", "contraindication", "renal", "drug interaction",
            "pharmacology", "medication", "dosage", "adverse effect",
            "antibiotic", "anticoagulant", "warfarin", "heparin", "statin",
            "beta blocker", "ace inhibitor", "nsaid", "opioid", "analgesic",
            "pharmacokinetics", "drug metabolism", "creatinine clearance",
            "renal impairment", "hepatic", "toxicity", "overdose",
        ],
        "summary": "Metformin contraindications and renal safety criteria",
        "example_q": "What are the contraindications for metformin use in patients with renal impairment?",
    },
    "Neurology": {
        "keywords": [
            "thunderclap", "headache", "subarachnoid", "sah", "stroke",
            "tia", "seizure", "epilepsy", "meningitis", "encephalitis",
            "multiple sclerosis", "parkinson", "alzheimer", "dementia",
            "neuropathy", "guillain", "migraine", "lumbar puncture",
            "mri brain", "ct head", "neuro", "cranial", "spinal",
            "vertebral", "disc herniation",
        ],
        "summary": "Thunderclap headache workup, SAH rule-out protocol",
        "example_q": "A patient presents with a thunderclap headache. How do you rule out subarachnoid hemorrhage?",
    },
    "Pediatrics": {
        "keywords": [
            "pediatric", "child", "infant", "newborn", "neonate",
            "vaccination", "vaccine", "immunization", "acip", "cdc schedule",
            "2-month", "4-month", "dtap", "mmr", "growth chart",
            "developmental", "febrile", "otitis", "intussusception",
            "kawasaki", "rsv", "bronchiolitis", "pediatrician",
        ],
        "summary": "2-month vaccination schedule, US CDC ACIP guidelines",
        "example_q": "What vaccines are recommended at the 2-month well-child visit per CDC ACIP guidelines?",
    },
    "Emergency": {
        "keywords": [
            "bls", "basic life support", "cpr", "resuscitation",
            "unresponsive", "cardiac arrest", "airway", "breathing",
            "circulation", "trauma", "hemorrhage", "shock", "anaphylaxis",
            "epinephrine", "defibrillation", "aed", "emergency",
            "triage", "acls", "advanced life support", "intubation",
            "chest compression", "drowning", "choking", "heimlich",
        ],
        "summary": "BLS protocol, unresponsive non-breathing patient",
        "example_q": "What are the steps for BLS in an unresponsive, non-breathing adult?",
    },
}

# Curated placeholder questions per domain (used as fallback AND as table examples)
PLACEHOLDER_QUESTIONS: Dict[str, List[Dict]] = {
    "Cardiology": [
        {"text": "A 65-year-old presents with inferior ST elevation. What is the management?",          "reference_answer": "Activate STEMI protocol. Aspirin 325mg, P2Y12 inhibitor. Primary PCI within 90 min."},
        {"text": "What are the indications for primary PCI in STEMI?",                                  "reference_answer": "STEMI within 12 hours, cardiogenic shock, failed thrombolysis."},
        {"text": "How do you manage acute atrial fibrillation with rapid ventricular response?",          "reference_answer": "Rate control with beta-blocker or calcium channel blocker. Anticoagulation if >48h."},
        {"text": "What troponin levels indicate myocardial injury?",                                    "reference_answer": "High-sensitivity troponin above 99th percentile URL indicates myocardial injury."},
        {"text": "When is thrombolysis preferred over PCI in STEMI?",                                  "reference_answer": "When PCI-capable facility cannot be reached within 120 minutes of first medical contact."},
    ],
    "Pharmacology": [
        {"text": "What are the contraindications for metformin use in patients with renal impairment?",  "reference_answer": "eGFR <30 mL/min/1.73m2 is contraindicated. Use with caution if eGFR 30-45."},
        {"text": "What are the major drug interactions with warfarin?",                                  "reference_answer": "Amiodarone, fluconazole, NSAIDs, broad-spectrum antibiotics increase INR."},
        {"text": "What class of antibiotics is avoided in children under 8 due to teeth discoloration?", "reference_answer": "Tetracyclines are contraindicated in children under 8 years of age."},
        {"text": "How does renal impairment affect aminoglycoside dosing?",                              "reference_answer": "Extend dosing intervals and monitor trough levels closely."},
        {"text": "What is serotonin syndrome and which drug combinations cause it?",                    "reference_answer": "Life-threatening excess serotonin. Caused by SSRIs + MAOIs, linezolid, tramadol."},
    ],
    "Neurology": [
        {"text": "A patient presents with a thunderclap headache. How do you rule out SAH?",            "reference_answer": "Non-contrast CT head first. If negative within 6h, LP for xanthochromia."},
        {"text": "What is the initial management of status epilepticus?",                               "reference_answer": "Lorazepam IV first-line. Fosphenytoin if benzodiazepine fails. Protect airway."},
        {"text": "How do you differentiate ischemic stroke from hemorrhagic stroke?",                   "reference_answer": "Non-contrast CT head. Hemorrhagic shows hyperdensity. Ischemic may be normal early."},
        {"text": "What are the diagnostic criteria for multiple sclerosis?",                            "reference_answer": "McDonald criteria: dissemination in space and time on MRI or clinical presentation."},
        {"text": "When is lumbar puncture indicated in bacterial meningitis workup?",                   "reference_answer": "After CT rules out raised ICP. Blood cultures first to avoid treatment delay."},
    ],
    "Pediatrics": [
        {"text": "What vaccines are recommended at the 2-month well-child visit per CDC ACIP?",         "reference_answer": "DTaP, Hib, IPV, PCV15/20, RV, HepB (2nd dose)."},
        {"text": "What are the signs of Kawasaki disease in a 3-year-old?",                            "reference_answer": "Fever >5 days plus 4 of 5: rash, conjunctivitis, mouth changes, hand changes, lymphadenopathy."},
        {"text": "How do you manage febrile seizures in a 2-year-old?",                                "reference_answer": "Most are simple and self-limiting. Antipyretics, reassure parents. Recurrence risk ~30%."},
        {"text": "What is the dosing of paracetamol in a 15 kg child?",                               "reference_answer": "10-15 mg/kg per dose every 4-6 hours. Max 75 mg/kg/day."},
        {"text": "When is RSV prophylaxis with palivizumab indicated?",                               "reference_answer": "Premature infants <29 weeks, infants with CHD or CLD in first RSV season."},
    ],
    "Emergency": [
        {"text": "What are the steps for BLS in an unresponsive, non-breathing adult?",                "reference_answer": "Call 911, 30 chest compressions : 2 breaths, use AED as soon as available."},
        {"text": "How do you manage anaphylaxis in the emergency department?",                          "reference_answer": "IM epinephrine 0.3-0.5mg in lateral thigh. IV fluids, diphenhydramine, steroids."},
        {"text": "What is the initial approach to a trauma patient (primary survey)?",                  "reference_answer": "ABCDE: Airway, Breathing, Circulation, Disability (neuro), Exposure."},
        {"text": "How do you manage a tension pneumothorax?",                                          "reference_answer": "Immediate needle decompression 2nd ICS MCL. Definitive chest tube."},
        {"text": "What is the Heimlich maneuver and when is it used?",                                 "reference_answer": "Abdominal thrusts for conscious choking adult. Alternate with back blows."},
    ],
}


def _detect_columns(fieldnames: List[str], q_hints: List[str], a_hints: List[str]):
    cols_lower = [c.lower() for c in fieldnames]
    q_col = next((fieldnames[i] for i, c in enumerate(cols_lower) if any(h in c for h in q_hints)), fieldnames[0] if fieldnames else None)
    a_col = next((fieldnames[i] for i, c in enumerate(cols_lower) if any(h in c for h in a_hints)), fieldnames[1] if len(fieldnames) > 1 else None)
    return q_col, a_col


def classify_domain(text: str) -> Optional[str]:
    """Return the best-matching domain for a question, or None if no match."""
    text_lower = text.lower()
    scores: Dict[str, int] = {}
    for domain, defn in DOMAIN_DEFINITIONS.items():
        scores[domain] = sum(1 for kw in defn["keywords"] if kw in text_lower)
    best_domain = max(scores, key=lambda d: scores[d])
    return best_domain if scores[best_domain] > 0 else None


def load_csv_questions(path: Path, source_name: str, max_per_domain: int) -> List[Dict]:
    """Load a CSV and classify rows into domains. Returns list of classified question dicts."""
    rows = []
    if not path.exists():
        print(f"  WARNING: {path.name} not found. Expected at: {path}")
        return rows
    domain_counts: Dict[str, int] = Counter()
    with open(path, encoding="utf-8", errors="ignore") as f:
        reader = csv.DictReader(f)
        q_col, a_col = _detect_columns(
            reader.fieldnames or [],
            ["question", "input", "text", "patient", "utterance", "prompt", "instruction"],
            ["answer", "output", "response", "doctor"]
        )
        for row in reader:
            q = (row.get(q_col) or "").strip()
            a = (row.get(a_col) or "").strip()
            if not q:
                continue
            domain = classify_domain(q)
            if domain and domain_counts[domain] < max_per_domain:
                rows.append({"text": q, "reference_answer": a, "source": source_name, "domain": domain})
                domain_counts[domain] += 1
            if all(domain_counts[d] >= max_per_domain for d in DOMAIN_DEFINITIONS):
                break  # all domains saturated
    loaded = len(rows)
    print(f"  {source_name}: {loaded} questions loaded across domains")
    for d, n in domain_counts.items():
        if n > 0:
            print(f"    {d}: {n}")
    return rows


def build_benchmark(raw_rows: List[Dict], max_per_domain: int) -> List[Dict]:
    """Build final benchmark — ensure every domain has questions (fill with placeholders if needed)."""
    domain_buckets: Dict[str, List[Dict]] = defaultdict(list)
    for row in raw_rows:
        domain_buckets[row["domain"]].append(row)

    benchmark = []
    q_id = 0
    for domain, defn in DOMAIN_DEFINITIONS.items():
        bucket = domain_buckets.get(domain, [])
        # If real data is short, fill with placeholders
        placeholders = PLACEHOLDER_QUESTIONS[domain]
        combined = bucket[:max_per_domain]
        if len(combined) < max_per_domain:
            needed = max_per_domain - len(combined)
            for p in placeholders[:needed]:
                combined.append({
                    "text": p["text"],
                    "reference_answer": p["reference_answer"],
                    "source": "placeholder",
                    "domain": domain,
                })
        for row in combined:
            benchmark.append({
                "id": f"q_{q_id:04d}",
                "text": row["text"],
                "domain": row["domain"],
                "category": row["domain"].lower().replace(" ", "_"),
                "source": row["source"],
                "reference_answer": row.get("reference_answer", ""),
                "domain_summary": defn["summary"],
                "domain_example": defn["example_q"],
            })
            q_id += 1
    return benchmark


def generate_benchmark_table(benchmark: List[Dict]) -> str:
    """Generate the Domain Question Summary markdown table for the paper."""
    counts = Counter(q["domain"] for q in benchmark)
    sources = Counter(q["source"] for q in benchmark)

    lines = [
        "# Benchmark Dataset — Domain Question Summary",
        "",
        "## Domain Overview",
        "",
        "| Domain | Question Summary | # Questions | Sources |",
        "|---|---|---|---|",
    ]
    for domain, defn in DOMAIN_DEFINITIONS.items():
        n = counts.get(domain, 0)
        lines.append(f"| {domain} | {defn['summary']} | {n} | MedQuAD, MedDialog, Medical Meadow |")

    lines += [
        f"| **Total** | | **{len(benchmark)}** | |",
        "",
        "## Representative Questions per Domain",
        "",
        "| Domain | Representative Question |",
        "|---|---|",
    ]
    for domain, defn in DOMAIN_DEFINITIONS.items():
        lines.append(f"| {domain} | {defn['example_q']} |")

    lines += [
        "",
        "## Source Dataset Breakdown",
        "",
        "| Source | # Questions |",
        "|---|---|",
    ]
    for src, n in sources.items():
        lines.append(f"| {src} | {n} |")

    lines += [
        "",
        "## Dataset Citations",
        "",
        "- **MedQuAD**: Ben Abacha A & Demner-Fushman D. A Question-Entailment Approach to Question Answering. *BMC Bioinformatics*. 2019.",
        "- **MedDialog**: Zeng G et al. MedDialog: Large-scale Medical Dialogue Datasets. *EMNLP 2020*.",
        "- **Medical Meadow Health Advice**: Han T et al. MedAlpaca. *arXiv 2023*.",
        "- **Origin repo**: https://github.com/m22oct2000/Multi-LLMs-as-Judge",
        "",
        "*Questions without sufficient real-data coverage are filled with curated domain-representative placeholders.*",
    ]
    return "\n".join(lines)


def main():
    with open(CONFIG_PATH) as f:
        config = json.load(f)

    max_per_domain = config.get("target_questions_per_domain", 20)

    print("=" * 70)
    print("Experiment 1: Structured Multi-Domain Medical Benchmark")
    print("Sources: MedQuAD | MedDialog | Medical Meadow Health Advice")
    print("Origin: https://github.com/m22oct2000/Multi-LLMs-as-Judge")
    print("=" * 70)
    print(f"Data dir: {DATA_DIR}")
    print(f"Target per domain: {max_per_domain}\n")

    raw_rows: List[Dict] = []
    raw_rows.extend(load_csv_questions(MEDQUAD_CSV,   "MedQuAD",       max_per_domain))
    raw_rows.extend(load_csv_questions(MEDDIALOG_CSV,  "MedDialog",     max_per_domain))
    raw_rows.extend(load_csv_questions(MEDMEADOW_CSV,  "MedicalMeadow", max_per_domain))
    print(f"\nTotal questions from real data: {len(raw_rows)}")

    benchmark = build_benchmark(raw_rows, max_per_domain)
    print(f"Final benchmark size: {len(benchmark)} questions")

    counts = Counter(q["domain"] for q in benchmark)
    sources = Counter(q["source"] for q in benchmark)
    print("\nDomain breakdown:")
    for domain in DOMAIN_DEFINITIONS:
        print(f"  {domain:15s}: {counts.get(domain, 0):3d} questions")
    print("\nSource breakdown:")
    for src, n in sources.items():
        print(f"  {src:20s}: {n:3d}")

    # Print the benchmark table to console (paper Table 1)
    print("\n" + "=" * 70)
    print("BENCHMARK TABLE (for paper):")
    print("=" * 70)
    print(f"{'Domain':<15} {'Question Summary':<55} {'#':>4}")
    print("-" * 76)
    for domain, defn in DOMAIN_DEFINITIONS.items():
        print(f"{domain:<15} {defn['summary']:<55} {counts.get(domain, 0):>4}")
    print("-" * 76)
    print(f"{'Total':<15} {'':<55} {len(benchmark):>4}")

    # Save benchmark JSON
    out_path = ROOT / config["output_files"]["questions_json"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    output = {
        "metadata": {
            "domains": list(DOMAIN_DEFINITIONS.keys()),
            "domain_summaries": {d: defn["summary"] for d, defn in DOMAIN_DEFINITIONS.items()},
            "domain_examples":  {d: defn["example_q"] for d, defn in DOMAIN_DEFINITIONS.items()},
            "sources": ["MedQuAD", "MedDialog", "MedicalMeadow"],
            "origin_repo": "https://github.com/m22oct2000/Multi-LLMs-as-Judge",
            "total_questions": len(benchmark),
            "per_domain_target": max_per_domain,
        },
        "questions": benchmark,
    }
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nSaved benchmark -> {out_path}")

    # Save markdown table
    table_md = generate_benchmark_table(benchmark)
    table_path = ROOT / config["output_files"]["dataset_table_md"]
    with open(table_path, "w") as f:
        f.write(table_md)
    print(f"Saved benchmark table -> {table_path}")

    # Save results JSON
    results_path = ROOT / config["output_files"]["results_json"]
    results_path.parent.mkdir(parents=True, exist_ok=True)
    with open(results_path, "w") as f:
        json.dump({
            "domain_counts": dict(counts),
            "source_counts": dict(sources),
            "total": len(benchmark),
        }, f, indent=2)
    print(f"Saved results -> {results_path}")


if __name__ == "__main__":
    main()
