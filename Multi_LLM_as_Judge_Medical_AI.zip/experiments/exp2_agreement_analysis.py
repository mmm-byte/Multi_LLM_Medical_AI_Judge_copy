"""Experiment 2: Per-Rubric Agreement Analysis (Core Experiment).

Loads the pre-labeled agreement benchmark CSV produced by
  benchmark_dataset/build_agreement_dataset.py
and runs all 4 judges on every row under all 5 rubrics.

For each (question, rubric) pair:
  - Sends question + reference_answer to all 4 judges via vLLM
  - Computes pairwise agreement across all 6 judge pairs
  - Classifies panel agreement: fully_agree / majority_agree / split / full_disagree / skipped
  - Compares observed_class to expected_class from the CSV
  - Prints all judge rationales to stdout

After all runs, writes back observed_class + verified flag to the CSV
so the benchmark CSV is a live record of ground-truth agreement.

Partial results are written after each rubric so exp4 can run even
if the pipeline is interrupted.

Run on HPC:
    python experiments/exp2_agreement_analysis.py

Outputs:
    results/exp2_agreement_results.json
    benchmark_dataset/agreement_benchmark.csv   (updated with observed_class)
"""
from __future__ import annotations

import csv
import json
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.consensus_core.models import Answer, Question, Rubric, RubricItem, new_id
from core.wrapper import ADRDJudgeRunner, PanelResult

CONFIG_PATH   = ROOT / 'config' / 'configs' / 'config_exp2_agreement.json'
BENCHMARK_CSV = ROOT / 'benchmark_dataset' / 'agreement_benchmark.csv'


def load_rubric(path: str) -> Rubric:
    with open(ROOT / path) as f:
        data = json.load(f)
    items = [
        RubricItem(
            id=it['id'], name=it['name'],
            description=it['description'],
            scale=it['scale'], weight=float(it['weight']),
            source_paper=data.get('source_paper', ''),
        )
        for it in data['items']
    ]
    return Rubric(
        id=data['id'], name=data['name'],
        source_paper=data['source_paper'],
        source_url=data.get('source_url'),
        items=items,
    )


def load_benchmark_csv(path) -> List[Dict]:
    """Load benchmark CSV. Accepts Path or None — exits cleanly on missing file."""
    if path is None:
        print('ERROR: benchmark CSV path is None.')
        print('Run this first: python benchmark_dataset/build_agreement_dataset.py')
        sys.exit(1)
    path = Path(path)
    if not path.exists():
        print(f'ERROR: Benchmark CSV not found at {path}')
        print('Run this first: python benchmark_dataset/build_agreement_dataset.py')
        sys.exit(1)
    with open(path, encoding='utf-8') as f:
        return list(csv.DictReader(f))


def write_benchmark_csv(path, rows: List[Dict]) -> None:
    if not rows:
        return
    path = Path(path)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _print_rubric_summary(rubric_block: Dict) -> None:
    results  = rubric_block['results']
    # Exclude skipped rows from summary percentages
    live     = [r for r in results if r.get('agreement_class') != 'skipped']
    skipped  = len(results) - len(live)
    total_q  = len(live)
    classes  = [r['agreement_class'] for r in live]
    counts   = Counter(classes)
    mean_pw  = (sum(r['mean_pairwise_agreement'] for r in live) / total_q
                if total_q else 0)
    print(f"\n{rubric_block['rubric_name']}:")
    for cls in ['fully_agree', 'majority_agree', 'split', 'full_disagree']:
        n = counts.get(cls, 0)
        pct = n / total_q * 100 if total_q else 0
        print(f'  {cls:<20}: {n:3d}/{total_q} ({pct:.1f}%)')
    if skipped:
        print(f'  {"skipped":<20}: {skipped:3d} rows (excluded from %)')
    print(f'  Mean pairwise : {mean_pw:.1f}%')


def main():
    with open(CONFIG_PATH) as f:
        config = json.load(f)

    benchmark_rows = load_benchmark_csv(BENCHMARK_CSV)
    print(f'Loaded {len(benchmark_rows)} questions from agreement benchmark CSV')

    row_by_id: Dict[str, Dict] = {r['id']: r for r in benchmark_rows}
    rubrics = [load_rubric(r) for r in config['rubrics']]
    runner  = ADRDJudgeRunner(config_path=str(CONFIG_PATH))

    out_path = ROOT / config['output_files']['results_json']
    out_path.parent.mkdir(parents=True, exist_ok=True)

    all_results: List[Dict[str, Any]] = []
    # Load any existing partial results so we can append
    if out_path.exists():
        try:
            with open(out_path) as f:
                all_results = json.load(f)
            already_done = {b['rubric_id'] for b in all_results}
            print(f'Resuming: {len(already_done)} rubric(s) already done: {already_done}')
        except Exception:
            all_results = []
            already_done = set()
    else:
        already_done = set()

    total = len(benchmark_rows) * len(rubrics)
    done  = len(already_done) * len(benchmark_rows)
    t_start = time.time()
    match_count = 0

    for rubric in rubrics:
        if rubric.id in already_done:
            print(f'\nSkipping already-done rubric: {rubric.id}')
            continue

        print(f"\n{'#'*70}")
        print(f'RUBRIC: {rubric.name}')
        print(f'SOURCE: {rubric.source_paper}')
        print(f"{'#'*70}")
        rubric_results = []

        for row in benchmark_rows:
            question = Question(
                id=row['id'], text=row['question'],
                category=row['domain'], source=row.get('source', ''),
            )
            answer = Answer(
                id=new_id('ans'), text=row.get('reference_answer', ''),
                provider='reference',
            )

            expected = row.get('expected_class', '')
            print(f"\n  Q [{question.category}] expected={expected}: {question.text[:70]}...")

            panel: PanelResult = runner.run(question, answer, rubric)
            observed = panel.agreement_class

            # Log how many judges ran
            n_judges_ran = len([jr for jr in panel.judge_results if jr.raw_response.strip()])
            if n_judges_ran < len(runner.judges):
                print(f'  ⚠️  Only {n_judges_ran}/{len(runner.judges)} judges produced output')

            if not panel.skipped and row['id'] in row_by_id:
                row_by_id[row['id']]['observed_class'] = observed
                row_by_id[row['id']]['verified'] = 'yes' if observed == expected else 'no'
                row_by_id[row['id']]['judges_ran'] = str(n_judges_ran)
                if observed == expected:
                    match_count += 1

            rubric_results.append(panel.to_dict())
            done += 1
            elapsed = time.time() - t_start
            match_flag = '✓' if observed == expected else '✗'
            print(f'  [{done}/{total}] {match_flag} expected={expected} '
                  f'observed={observed} | '
                  f'MeanPW={panel.mean_pairwise_agreement:.1f}% | '
                  f'judges={n_judges_ran} | {elapsed:.0f}s')
            if panel.outlier_judge:
                print(f'  ⚠️  Outlier: {panel.outlier_judge}')

        rubric_block = {
            'rubric_id':       rubric.id,
            'rubric_name':     rubric.name,
            'source_paper':    rubric.source_paper,
            'results':         rubric_results,
        }
        all_results.append(rubric_block)

        # Write partial results after EVERY rubric (so exp4 can run even if pipeline stops)
        with open(out_path, 'w') as f:
            json.dump(all_results, f, indent=2)
        print(f'  ✓ Partial results saved -> {out_path}')

        _print_rubric_summary(rubric_block)

    # Write observed_class back to CSV
    write_benchmark_csv(BENCHMARK_CSV, list(row_by_id.values()))
    print(f'\nUpdated agreement_benchmark.csv with observed_class '
          f'(verified rows: {match_count}/{len(benchmark_rows)})')

    # Final summary across all rubrics
    print('\n' + '='*70)
    print('AGREEMENT SUMMARY')
    print('='*70)
    for rubric_block in all_results:
        _print_rubric_summary(rubric_block)

    print(f'\nResults saved -> {out_path}')
    total_questions = len(benchmark_rows)
    if total_questions:
        print(f'Heuristic verification rate: {match_count}/{total_questions} = '
              f'{match_count/total_questions*100:.1f}%')


if __name__ == '__main__':
    main()
