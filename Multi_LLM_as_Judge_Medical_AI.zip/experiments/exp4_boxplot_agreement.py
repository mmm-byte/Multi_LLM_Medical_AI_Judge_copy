"""Experiment 4: Cross-Domain Agreement Box Plots.

Loads results from exp2 and generates box plots:
  - One box plot per rubric (5 rubrics)
  - X-axis: 5 clinical domains
  - Y-axis: mean pairwise agreement score (0-100%)
  - Mean and median labeled on each box
  - Empty domains shown as grey 'no data' markers (not phantom 0-boxes)
  - Skipped rows excluded from all plots
  - Exported as high-resolution PNG (300 DPI) for Overleaf

Run on HPC:
    python experiments/exp4_boxplot_agreement.py

Outputs:
    results/figures/fig_exp2_agreement_<rubric_id>.png  (one per rubric)
    results/figures/fig_exp4_boxplot_by_domain.png      (combined 3x2 panel)
    results/exp4_boxplot_data.json
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

CONFIG_PATH       = ROOT / 'config' / 'configs' / 'config_exp4_boxplots.json'
EXP2_RESULTS_PATH = ROOT / 'results' / 'exp2_agreement_results.json'


def _safe_scores(cat_scores: Dict[str, List[float]], dom: str) -> List[float]:
    """Return scores for a domain, or empty list (never [0.0] dummy)."""
    return cat_scores.get(dom, [])


def _plot_rubric_block(ax, data_to_plot, domains, box_colors, rubric_name,
                       has_data_flags):
    """Plot one rubric block onto ax. Domains with no data get a grey marker."""
    import numpy as np

    # Only pass non-empty series to boxplot
    positions  = [i + 1 for i, d in enumerate(data_to_plot) if d]
    plot_data  = [d for d in data_to_plot if d]

    if plot_data:
        bp = ax.boxplot(plot_data, positions=positions, patch_artist=True,
                        notch=False, widths=0.55)
        colors_used = [box_colors[i] for i, d in enumerate(data_to_plot) if d]
        for patch, color in zip(bp['boxes'], colors_used):
            patch.set_facecolor(color)
            patch.set_alpha(0.72)
        for i, (line, data) in enumerate(zip(bp['medians'], plot_data)):
            pos      = positions[i]
            median_v = float(np.median(data))
            mean_v   = float(np.mean(data))
            ax.text(pos, median_v + 1.5, f'med={median_v:.1f}',
                    ha='center', fontsize=7)
            ax.text(pos, mean_v  - 4.0,  f'\u03bc={mean_v:.1f}',
                    ha='center', fontsize=7, color='#555')

    # Grey 'no data' markers for empty domains
    for i, d in enumerate(data_to_plot):
        if not d:
            ax.text(i + 1, 50, 'no data', ha='center', va='center',
                    fontsize=7, color='#aaa',
                    bbox=dict(boxstyle='round,pad=0.2', fc='#f5f5f5', ec='#ccc'))

    ax.set_xticks(range(1, len(domains) + 1))
    ax.set_xticklabels(domains, fontsize=9)
    ax.set_ylim(0, 115)
    ax.axhline(80, color='red', linestyle='--', linewidth=0.8,
               alpha=0.6, label='80% threshold')
    ax.grid(axis='y', linestyle='--', alpha=0.45)


def main():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np

    with open(CONFIG_PATH) as f:
        config = json.load(f)

    if not EXP2_RESULTS_PATH.exists():
        print(f'Exp2 results not found at {EXP2_RESULTS_PATH}. Run exp2 first.')
        sys.exit(1)

    with open(EXP2_RESULTS_PATH) as f:
        exp2_data = json.load(f)

    fig_dir    = ROOT / config['output_files']['figure_dir']
    fig_dir.mkdir(parents=True, exist_ok=True)
    domains    = config['categories']
    dpi        = config.get('figure_dpi', 300)
    box_colors = ['#4C72B0', '#55A868', '#C44E52', '#8172B2', '#CCB974']

    boxplot_data: List[Dict] = []

    for rubric_block in exp2_data:
        rubric_id   = rubric_block['rubric_id']
        rubric_name = rubric_block['rubric_name']
        results     = rubric_block['results']

        # Exclude skipped rows
        live = [r for r in results if r.get('agreement_class') != 'skipped']

        cat_scores: Dict[str, List[float]] = defaultdict(list)
        for r in live:
            cat = r.get('question_category', 'unknown')
            cat_scores[cat].append(r['mean_pairwise_agreement'])

        data_to_plot  = [_safe_scores(cat_scores, dom) for dom in domains]
        has_data      = [bool(d) for d in data_to_plot]

        fig, ax = plt.subplots(figsize=(11, 6))
        _plot_rubric_block(ax, data_to_plot, domains, box_colors,
                           rubric_name, has_data)
        ax.set_ylabel('Mean Pairwise Agreement (%)', fontsize=11)
        ax.set_title(f'Inter-Judge Agreement by Clinical Domain\n{rubric_name}',
                     fontsize=12, fontweight='bold')
        ax.legend(fontsize=8)
        plt.tight_layout()

        fig_path = fig_dir / f'fig_exp2_agreement_{rubric_id}.png'
        fig.savefig(fig_path, dpi=dpi, bbox_inches='tight')
        plt.close(fig)
        print(f'Saved: {fig_path}')

        boxplot_data.append({
            'rubric_id':     rubric_id,
            'rubric_name':   rubric_name,
            'domain_scores': {dom: cat_scores.get(dom, []) for dom in domains},
        })

    # Combined multi-panel figure (3x2 for 5 rubrics + empty slot)
    fig, axes = plt.subplots(2, 3, figsize=(18, 11))
    axes_flat = axes.flatten()

    for idx, rubric_block in enumerate(exp2_data[:5]):
        ax          = axes_flat[idx]
        rubric_name = rubric_block['rubric_name']
        results     = rubric_block['results']
        live        = [r for r in results if r.get('agreement_class') != 'skipped']
        cat_scores  = defaultdict(list)
        for r in live:
            cat = r.get('question_category', 'unknown')
            cat_scores[cat].append(r['mean_pairwise_agreement'])
        data_to_plot = [_safe_scores(cat_scores, dom) for dom in domains]
        has_data     = [bool(d) for d in data_to_plot]
        _plot_rubric_block(ax, data_to_plot,
                           [d[:5] for d in domains],
                           box_colors, rubric_name, has_data)
        ax.set_ylabel('Mean PW Agr (%)', fontsize=8)
        ax.set_title(rubric_name.split('\u2014')[0].strip(),
                     fontsize=9, fontweight='bold')

    if len(exp2_data) < 6:
        axes_flat[5].set_visible(False)

    fig.suptitle(
        'Inter-Judge Agreement by Clinical Domain \u2014 All 5 Rubrics\n'
        '(PEMAT | HealthBench | Clinical Eval | Prometheus | PEMAT-Likert)',
        fontsize=13, fontweight='bold', y=1.01,
    )
    plt.tight_layout()
    combined_path = fig_dir / 'fig_exp4_boxplot_by_domain.png'
    fig.savefig(combined_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)
    print(f'Saved combined figure: {combined_path}')

    out_path = ROOT / config['output_files']['results_json']
    with open(out_path, 'w') as f:
        json.dump(boxplot_data, f, indent=2)
    print(f'Boxplot data saved -> {out_path}')


if __name__ == '__main__':
    main()
