"""Experiment 3: Rubric Sensitivity Analysis.

Tests each of the 4 published rubrics under 3 scoring variants:
  - BINARY (0/1)
  - LIKERT_1_5 (1-5 integer)
  - SCALED_0_10 (0-10 continuous)

Measures which scoring system produces the most stable inter-judge agreement.
Ablation: identifies rubric-scoring combinations that are indistinguishable
(agreement std < threshold) and flags them for removal in paper.

Data source: benchmark_dataset/adrd_questions.json
  Built by:  benchmark_dataset/build_adrd_questions.py
  Which reads: benchmark_dataset/agreement_benchmark.csv

Run on HPC:
    python benchmark_dataset/build_agreement_dataset.py
    python benchmark_dataset/build_adrd_questions.py
    python experiments/exp3_rubric_sensitivity.py

Outputs:
    results/exp3_sensitivity_results.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.consensus_core.models import Answer, Question, Rubric, RubricItem, new_id
from core.wrapper import ADRDJudgeRunner

CONFIG_PATH    = ROOT / 'config' / 'configs' / 'config_exp3_rubric_sensitivity.json'
QUESTIONS_PATH = ROOT / 'benchmark_dataset' / 'adrd_questions.json'


def load_rubric_raw(path: str) -> Dict:
    with open(ROOT / path) as f:
        return json.load(f)


SCALE_RANGE = {
    'BINARY':      (0.0, 1.0),
    'LIKERT_1_5':  (1.0, 5.0),
    'SCALED_0_10': (0.0, 10.0),
}


def build_rubric_variant(rubric_raw: Dict, scoring_variant: str) -> Rubric:
    """Create a Rubric with all items forced to the specified scoring variant.

    Stores scale_min and scale_max on item description so rubric_engine
    can normalise correctly (via the injected suffix convention).
    """
    scale_map = {
        'BINARY':      'BINARY',
        'LIKERT_1_5':  'LIKERT',
        'SCALED_0_10': 'LIKERT',
    }
    scale        = scale_map[scoring_variant]
    lo, hi       = SCALE_RANGE[scoring_variant]
    range_suffix = '' if scoring_variant == 'LIKERT_1_5' else f' Score {int(lo)}-{int(hi)}.'

    items = [
        RubricItem(
            id=it['id'], name=it['name'],
            description=it['description'] + range_suffix,
            scale=scale, weight=float(it.get('weight', 1.0)),
            source_paper=rubric_raw.get('source_paper', ''),
        )
        for it in rubric_raw['items']
    ]
    return Rubric(
        id=f"{rubric_raw['id']}_{scoring_variant.lower()}",
        name=f"{rubric_raw['name']} [{scoring_variant}]",
        source_paper=rubric_raw['source_paper'],
        items=items,
        # Pass scale range via metadata for rubric_engine normalisation
    )


def main():
    import statistics

    if not QUESTIONS_PATH.exists():
        print(f'ERROR: {QUESTIONS_PATH} not found.')
        print('Run these first:')
        print('  python benchmark_dataset/build_agreement_dataset.py')
        print('  python benchmark_dataset/build_adrd_questions.py')
        sys.exit(1)

    with open(CONFIG_PATH) as f:
        config = json.load(f)
    with open(QUESTIONS_PATH) as f:
        qdata = json.load(f)

    questions_raw = qdata['questions']
    if not questions_raw:
        print('No questions found in adrd_questions.json. Run build_adrd_questions.py.')
        sys.exit(1)

    runner   = ADRDJudgeRunner(config_path=str(CONFIG_PATH))
    variants = config['scoring_variants']
    all_results: List[Dict[str, Any]] = []

    for rubric_path in config['rubrics']:
        rubric_raw          = load_rubric_raw(rubric_path)
        rubric_variant_results = []

        for variant in variants:
            rubric = build_rubric_variant(rubric_raw, variant)
            print(f"\nRubric: {rubric_raw['name']} | Variant: {variant}")
            pw_scores: List[float] = []

            for qraw in questions_raw:
                q = Question(id=qraw['id'], text=qraw['text'],
                             category=qraw['category'])
                a = Answer(id=new_id('ans'),
                           text=qraw.get('reference_answer', ''),
                           provider='reference')
                panel = runner.run(q, a, rubric)
                if not panel.skipped:
                    pw_scores.append(panel.mean_pairwise_agreement)

            mean_pw = statistics.mean(pw_scores) if pw_scores else 0.0
            std_pw  = statistics.stdev(pw_scores) if len(pw_scores) > 1 else 0.0
            rubric_variant_results.append({
                'rubric_id':                rubric_raw['id'],
                'scoring_variant':          variant,
                'scale_range':              f"{SCALE_RANGE[variant][0]}-{SCALE_RANGE[variant][1]}",
                'mean_pairwise_agreement':  round(mean_pw, 2),
                'std_pairwise_agreement':   round(std_pw,  2),
                'n_questions':              len(pw_scores),
                'per_question_scores':      [round(s, 2) for s in pw_scores],
            })
            print(f'  Mean PW: {mean_pw:.2f}%  Std: {std_pw:.2f}%  n={len(pw_scores)}')

        all_results.append({
            'rubric_id':   rubric_raw['id'],
            'rubric_name': rubric_raw['name'],
            'variants':    rubric_variant_results,
        })

    # Ablation: flag variants with std < 5% as indistinguishable
    print('\nABLATION — Indistinguishable scoring variants (std < 5%):')
    flagged = 0
    for block in all_results:
        for v in block['variants']:
            if v['std_pairwise_agreement'] < 5.0:
                print(f"  ⚠️  {block['rubric_name']} [{v['scoring_variant']}] "
                      f"std={v['std_pairwise_agreement']}% — consider removing")
                flagged += 1
    if not flagged:
        print('  None (all variants show meaningful std)')

    out_path = ROOT / config['output_files']['results_json']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, 'w') as f:
        json.dump(all_results, f, indent=2)
    print(f'\nResults saved to {out_path}')


if __name__ == '__main__':
    main()
