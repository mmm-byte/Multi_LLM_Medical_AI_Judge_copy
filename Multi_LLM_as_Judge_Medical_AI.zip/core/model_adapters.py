"""Per-model prompt adapters for the ADRD judge panel.

Key design decisions per model:

  MedGemma   (instruction-tuned, 8192 ctx)
    - /v1/chat/completions, system + user roles
    - Full rubric descriptions affordable
    - Clean JSON or pipe format output expected

  BioMistral (BASE Mistral, 4096 ctx — no chat template in vLLM)
    - /v1/completions with raw prompt text
    - Short rubric names only; stop on double newline

  Meditron   (BASE LLaMA-2, 2048 ctx — no chat template in vLLM)
    - /v1/completions with raw prompt text
    - Stop at triple newline

  BioMedLM   (BASE GPT-2 arch, 1536 ctx)
    - serve_biomedlm.py exposes /v1/completions
    - Ultra-short prompt to stay within 1536 ctx
    - Stop at double newline

Forced output format (pipe format):
    U1: 1 | Plain language used throughout.
    U2: 0 | Sentences too complex.

Parser regex: r'^(\\w+):\\s*([0-5]|NA)\\s*\\|(.+)'
Fallback:     bare digit scan near item ID
Final:        NA sentinel if still not found
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from core.consensus_core.models import JudgeScore, RubricItem, new_id


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ENDPOINT_CHAT       = 'chat'        # /v1/chat/completions
ENDPOINT_COMPLETION = 'completion'  # /v1/completions


# ---------------------------------------------------------------------------
# Shared parser
# ---------------------------------------------------------------------------

SCORE_LINE_RE = re.compile(
    r'^([A-Za-z]{1,4}\d{0,2})\s*:\s*([0-5]|NA)\s*\|(.+)',
    re.IGNORECASE | re.MULTILINE,
)

FALLBACK_RE = re.compile(
    r'([A-Za-z]{1,4}\d{0,2})\s*[=:\s]+([0-5]|NA)',
    re.IGNORECASE,
)


def _parse_pipe_format(
    raw: str,
    rubric_items: List[RubricItem],
    judge_id: str,
) -> List[JudgeScore]:
    """Universal parser: pipe format primary, bare-digit fallback, NA sentinel."""
    item_ids   = [it.id.upper() for it in rubric_items]
    found: Dict[str, Tuple[str, str]] = {}

    # Tier 1: pipe format  "U1: 1 | reason"
    for m in SCORE_LINE_RE.finditer(raw):
        iid = m.group(1).upper()
        if iid in item_ids and iid not in found:
            found[iid] = (m.group(2), m.group(3).strip())

    # Tier 2: fallback  "U1=1", "U1 1", "U1: 1"
    if len(found) < len(item_ids):
        for m in FALLBACK_RE.finditer(raw):
            iid = m.group(1).upper()
            if iid in item_ids and iid not in found:
                found[iid] = (m.group(2), '(extracted)')

    # Tier 3: NA sentinel
    return [
        JudgeScore(
            id=new_id('sc'),
            judge_id=judge_id,
            rubric_item_id=it.id,
            score=found.get(it.id.upper(), ('NA', '(no score found)'))[0],
            rationale=found.get(it.id.upper(), ('NA', '(no score found)'))[1],
        )
        for it in rubric_items
    ]


# ---------------------------------------------------------------------------
# Prompt helpers
# ---------------------------------------------------------------------------

def _safe_first_word(name: Optional[str], fallback: str) -> str:
    words = (name or '').split()
    return words[0] if words else fallback


def _rubric_lines(rubric_items: List[RubricItem], short: bool = True) -> str:
    lines = []
    for it in rubric_items:
        scale = '1/0/NA' if (it.scale or '').upper() == 'BINARY' else '1-5'
        if short:
            desc = (it.description or '').split('.')[0].strip()
            lines.append(f'  {it.id} [{scale}] {it.name}: {desc}')
        else:
            lines.append(f'  {it.id} [{scale}] {it.name}: {it.description}')
    return '\n'.join(lines)


def _scale_instruction(rubric_items: List[RubricItem]) -> str:
    if all((it.scale or '').upper() == 'BINARY' for it in rubric_items):
        return '1=meets, 0=does not meet, NA=not applicable'
    return '1=poor 2=below avg 3=avg 4=good 5=excellent'


def _example_line(rubric_items: List[RubricItem]) -> str:
    it = rubric_items[0]
    sc = '1' if (it.scale or '').upper() == 'BINARY' else '4'
    return f'{it.id}: {sc} | Brief one-line rationale.'


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class BaseAdapter:
    MAX_NEW_TOKENS: int  = 200
    STOP: List[str]      = []
    ENDPOINT: str        = ENDPOINT_CHAT

    def build_messages(
        self,
        rubric_items: List[RubricItem],
        question_text: str,
        answer_text: str,
    ) -> List[Dict]:
        raise NotImplementedError

    def extra_params(self) -> Dict:
        p: Dict = {'max_tokens': self.MAX_NEW_TOKENS}
        if self.STOP:
            p['stop'] = self.STOP
        return p

    def parse(
        self,
        raw: str,
        rubric_items: List[RubricItem],
        judge_id: str,
    ) -> List[JudgeScore]:
        return _parse_pipe_format(raw, rubric_items, judge_id)


# ---------------------------------------------------------------------------
# MedGemma  — instruction-tuned, system+user
# ---------------------------------------------------------------------------

class MedGemmaAdapter(BaseAdapter):
    MAX_NEW_TOKENS = 200
    STOP           = []
    ENDPOINT       = ENDPOINT_CHAT

    def build_messages(self, rubric_items, question_text, answer_text):
        system = (
            'You are a strict medical evaluator. '
            'Score each rubric item using ONLY the format shown. '
            'Do not add any other text.\n\n'
            'RUBRIC ITEMS:\n'
            + _rubric_lines(rubric_items, short=False)
            + '\n\nScale: ' + _scale_instruction(rubric_items)
            + '\nRequired output — one line per item:\n'
            + _example_line(rubric_items)
        )
        user = (
            f'QUESTION: {question_text}\n\n'
            f'ANSWER: {answer_text}\n\n'
            'Score every item now:'
        )
        return [
            {'role': 'system', 'content': system},
            {'role': 'user',   'content': user},
        ]


# ---------------------------------------------------------------------------
# BioMistral — BASE Mistral, 4096 ctx — NO chat template in vLLM
# FIX: switched from ENDPOINT_CHAT to ENDPOINT_COMPLETION
#      vLLM rejects /v1/chat/completions with 400 when no chat template is set.
#      Use /v1/completions with a raw formatted prompt instead.
# ---------------------------------------------------------------------------

class BioMistralAdapter(BaseAdapter):
    MAX_NEW_TOKENS = 200
    STOP           = ['\n\n', '</s>']
    ENDPOINT       = ENDPOINT_COMPLETION   # FIX: was ENDPOINT_CHAT

    def build_messages(self, rubric_items, question_text, answer_text):
        rubric_block = _rubric_lines(rubric_items, short=True)
        scale        = _scale_instruction(rubric_items)
        example      = _example_line(rubric_items)
        # Raw completion prompt — no [INST] tags needed since we use /v1/completions
        prompt = (
            'Medical evaluator. Score each rubric item. One line per item. '
            'Format: ID: score | reason.\n'
            f'Scale: {scale}\n'
            f'Rubric:\n{rubric_block}\n'
            f'Question: {question_text}\n'
            f'Answer: {answer_text}\n'
            f'Example: {example}\n'
            'Scores:\n'
        )
        return [{'prompt': prompt}]


# ---------------------------------------------------------------------------
# Meditron — BASE LLaMA-2, 2048 ctx — NO chat template in vLLM
# FIX: switched from ENDPOINT_CHAT to ENDPOINT_COMPLETION
#      vLLM rejects /v1/chat/completions with 400 when no chat template is set.
# ---------------------------------------------------------------------------

class MeditronAdapter(BaseAdapter):
    MAX_NEW_TOKENS = 150
    STOP           = ['\n\n\n', '###', 'Question:']
    ENDPOINT       = ENDPOINT_COMPLETION   # FIX: was ENDPOINT_CHAT

    def build_messages(self, rubric_items, question_text, answer_text):
        scale     = _scale_instruction(rubric_items)
        items_str = ' '.join(f'{it.id}=?' for it in rubric_items)
        example   = _example_line(rubric_items)
        # Short prompt to fit within 2048 ctx
        prompt = (
            f'Medical scoring. Scale: {scale}.\n'
            f'Items: {items_str}\n'
            f'Q: {question_text}\n'
            f'A: {answer_text}\n'
            f'Format: {example}\n'
            'Scores:\n'
        )
        return [{'prompt': prompt}]

    def parse(self, raw, rubric_items, judge_id):
        return _parse_pipe_format(raw, rubric_items, judge_id)


# ---------------------------------------------------------------------------
# BioMedLM — BASE GPT-2 arch, 1536 ctx
# FIX: ultra-short prompt — previous prompt caused 500 (tokenization overflow)
#      Truncate Q+A to 200 chars each to stay well within 1536 ctx window.
# ---------------------------------------------------------------------------

class BioMedLMAdapter(BaseAdapter):
    MAX_NEW_TOKENS = 80
    STOP           = ['\n\n', 'Q:', 'Question:']
    ENDPOINT       = ENDPOINT_COMPLETION   # /v1/completions

    def build_messages(self, rubric_items, question_text, answer_text):
        scale     = _scale_instruction(rubric_items)
        items_str = ', '.join(
            f"{it.id}({_safe_first_word(it.name, it.id)})"
            for it in rubric_items
        )
        first_id  = rubric_items[0].id if rubric_items else 'X1'
        # Truncate to avoid 1536-token overflow
        q_short = question_text[:150]
        a_short = answer_text[:150]
        prompt = (
            f'Q: {q_short}\n'
            f'A: {a_short}\n'
            f'Rate {items_str}. {scale}.\n'
            f'{first_id}: '
        )
        return [{'prompt': prompt}]

    def parse(self, raw, rubric_items, judge_id):
        first_id = rubric_items[0].id if rubric_items else ''
        reconstructed = f'{first_id}: {raw}' if raw and not raw.startswith(first_id) else raw
        return _parse_pipe_format(reconstructed, rubric_items, judge_id)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

ADAPTER_REGISTRY: Dict[str, BaseAdapter] = {
    'medgemma':   MedGemmaAdapter(),
    'biomistral': BioMistralAdapter(),
    'meditron':   MeditronAdapter(),
    'biomedlm':   BioMedLMAdapter(),
}


def get_adapter(judge_id: str) -> BaseAdapter:
    return ADAPTER_REGISTRY.get(judge_id, BioMistralAdapter())
