"""ADRDJudgeRunner — runs the full judge panel for one (question, answer, rubric) triple.

Routing logic:
  - Instruction-tuned models (medgemma, biomistral):
      POST /v1/chat/completions  with {messages: [{role, content}]}
  - Base models (meditron, biomedlm):
      POST /v1/completions       with {prompt: "raw text"}

Pre-flight check:
  - Before running any row, verify >= 2 judges are reachable
  - If < 2 judges respond, skip row and log as 'skipped' (not 'full_disagree')

All judges run concurrently via ThreadPoolExecutor.
No mediation loop.
"""
from __future__ import annotations

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from itertools import combinations
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.consensus_core.models import (
    Answer, JudgeScore, Question, Rubric, new_id,
)
from core.consensus_core.events import EventLog, append_judgment_recorded, append_agreement_classified
from core.consensus_core.repository import InMemoryStore
from core.rubric_engine import DynamicRubricParser
from core.agreement import classify_panel_agreement, summarize_agreement
from core.metrics import get_metrics_collector
from core.model_adapters import get_adapter, ENDPOINT_CHAT, ENDPOINT_COMPLETION

logger = logging.getLogger('adrd_judge_runner')


@dataclass
class JudgeResult:
    judge_id: str
    aggregate_score: float
    scores: List[Dict]
    raw_response: str
    latency_ms: float


@dataclass
class PanelResult:
    question_id: str
    question_text: str
    question_category: str
    rubric_id: str
    rubric_name: str
    rubric_source_paper: str
    judge_results: List[JudgeResult]
    agreement_summary: Dict
    agreement_class: str
    outlier_judge: Optional[str]
    mean_pairwise_agreement: float
    events_jsonl: str
    skipped: bool = False

    def to_dict(self) -> Dict:
        return asdict(self)


class ADRDJudgeRunner:
    AGREEMENT_THRESHOLD  = 80.0
    MIN_JUDGES_REQUIRED  = 2     # skip row if fewer than this many judges respond

    def __init__(self, config_path: str):
        with open(config_path) as f:
            self.config: Dict[str, Any] = json.load(f)
        self.judges: List[Dict] = self.config['judges']
        self.metrics = get_metrics_collector()
        self.store   = InMemoryStore()
        logger.info(f'ADRDJudgeRunner: {len(self.judges)} judges')
        for j in self.judges:
            logger.info(f'  {j["id"]} | {j["model"]} | {j["url"]}')

    # ------------------------------------------------------------------
    # Internal: call one judge via the correct endpoint
    # ------------------------------------------------------------------

    def _call_judge(
        self,
        judge: Dict,
        messages: List[Dict],
        extra: Dict,
        endpoint: str,
    ) -> Tuple[str, float]:
        import httpx
        t0      = time.time()
        base_url = judge['url']
        temp     = float(self.config.get('temperature', 0.0))

        if endpoint == ENDPOINT_COMPLETION:
            # Base model: /v1/completions with raw prompt text
            prompt_text = messages[0]['prompt']
            payload = {
                'model':       judge['model'],
                'prompt':      prompt_text,
                'temperature': temp,
                **extra,
            }
            url = f'{base_url}/v1/completions'
            resp = httpx.post(url, json=payload,
                              timeout=float(self.config.get('timeout_seconds', 120)))
            resp.raise_for_status()
            latency_ms = (time.time() - t0) * 1000
            # /v1/completions returns choices[0].text
            return resp.json()['choices'][0]['text'], latency_ms

        else:
            # Instruction-tuned: /v1/chat/completions
            payload = {
                'model':       judge['model'],
                'messages':    messages,
                'temperature': temp,
                **extra,
            }
            url = f'{base_url}/v1/chat/completions'
            resp = httpx.post(url, json=payload,
                              timeout=float(self.config.get('timeout_seconds', 120)))
            resp.raise_for_status()
            latency_ms = (time.time() - t0) * 1000
            return resp.json()['choices'][0]['message']['content'], latency_ms

    def _call_judge_safe(
        self,
        judge: Dict,
        messages: List[Dict],
        extra: Dict,
        endpoint: str,
    ) -> Tuple[str, str, float]:
        jid = judge['id']
        try:
            raw, lat = self._call_judge(judge, messages, extra, endpoint)
            return jid, raw, lat
        except Exception as e:
            logger.error(f'Judge {jid} failed: {e}')
            return jid, '', 0.0

    # ------------------------------------------------------------------
    # Pre-flight: verify enough judges are alive before running a row
    # ------------------------------------------------------------------

    def _preflight_check(self) -> List[str]:
        """Ping each judge's /v1/models endpoint. Return list of live judge IDs."""
        import httpx
        live = []
        for judge in self.judges:
            try:
                r = httpx.get(f"{judge['url']}/v1/models", timeout=5.0)
                if r.status_code == 200:
                    live.append(judge['id'])
                else:
                    logger.warning(f'Judge {judge["id"]} /v1/models returned {r.status_code}')
            except Exception as e:
                logger.warning(f'Judge {judge["id"]} unreachable: {e}')
        logger.info(f'Pre-flight: {len(live)}/{len(self.judges)} judges live: {live}')
        return live

    # ------------------------------------------------------------------
    # Public: run full panel
    # ------------------------------------------------------------------

    def run(
        self,
        question: Question,
        answer: Answer,
        rubric: Rubric,
    ) -> PanelResult:

        # Pre-flight check
        live_judges = self._preflight_check()
        if len(live_judges) < self.MIN_JUDGES_REQUIRED:
            logger.error(
                f'Only {len(live_judges)} judges live for Q={question.id} '
                f'rubric={rubric.id} — skipping row (need >= {self.MIN_JUDGES_REQUIRED})'
            )
            print(f'  [SKIPPED] Q={question.id} rubric={rubric.id} — '
                  f'only {len(live_judges)} judge(s) alive: {live_judges}')
            return PanelResult(
                question_id=question.id, question_text=question.text,
                question_category=question.category or 'unknown',
                rubric_id=rubric.id, rubric_name=rubric.name,
                rubric_source_paper=rubric.source_paper,
                judge_results=[], agreement_summary={},
                agreement_class='skipped', outlier_judge=None,
                mean_pairwise_agreement=0.0, events_jsonl='',
                skipped=True,
            )

        log          = EventLog()
        judge_results: List[JudgeResult]          = []
        all_scores:   Dict[str, List[JudgeScore]] = {}

        # Build per-judge prompts using each model's adapter
        judge_prompts: Dict[str, Tuple[List[Dict], Dict, str]] = {}
        for judge in self.judges:
            adapter  = get_adapter(judge['id'])
            messages = adapter.build_messages(rubric.items, question.text, answer.text)
            extra    = adapter.extra_params()
            judge_prompts[judge['id']] = (messages, extra, adapter.ENDPOINT)

        # Parallel execution — only run judges that passed pre-flight
        active_judges = [j for j in self.judges if j['id'] in live_judges]
        raw_responses: Dict[str, Tuple[str, float]] = {}
        with ThreadPoolExecutor(max_workers=len(active_judges)) as pool:
            futures = {
                pool.submit(
                    self._call_judge_safe,
                    judge,
                    judge_prompts[judge['id']][0],
                    judge_prompts[judge['id']][1],
                    judge_prompts[judge['id']][2],
                ): judge
                for judge in active_judges
            }
            for future in as_completed(futures):
                jid, raw, lat = future.result()
                raw_responses[jid] = (raw, lat)
                logger.info(f'Judge {jid} returned {len(raw)} chars in {lat:.0f}ms')

        # Check how many actually returned non-empty responses
        responded = [jid for jid, (raw, _) in raw_responses.items() if raw.strip()]
        if len(responded) < self.MIN_JUDGES_REQUIRED:
            logger.error(
                f'Only {len(responded)} judges returned output for Q={question.id} '
                f'rubric={rubric.id} — marking as skipped'
            )
            print(f'  [SKIPPED] Q={question.id} — only {len(responded)} non-empty responses')
            return PanelResult(
                question_id=question.id, question_text=question.text,
                question_category=question.category or 'unknown',
                rubric_id=rubric.id, rubric_name=rubric.name,
                rubric_source_paper=rubric.source_paper,
                judge_results=[], agreement_summary={},
                agreement_class='skipped', outlier_judge=None,
                mean_pairwise_agreement=0.0, events_jsonl='',
                skipped=True,
            )

        parser = DynamicRubricParser(rubric)

        for judge in active_judges:
            jid      = judge['id']
            raw, lat = raw_responses.get(jid, ('', 0.0))
            adapter  = get_adapter(jid)

            judge_scores = adapter.parse(raw, rubric.items, jid)
            agg          = parser.aggregate_score(judge_scores)
            rationales   = {s.rubric_item_id: (s.rationale or '') for s in judge_scores}

            # Print all scores + rationales to stdout
            print(f"\n{'='*60}")
            print(f'JUDGE: {jid} | RUBRIC: {rubric.name} | Q: {question.id}')
            print(f'Aggregate Score: {agg:.2f}')
            if raw:
                preview = raw[:300] + ('...' if len(raw) > 300 else '')
                print(f'Raw ({len(raw)} chars): {preview}')
            for s in judge_scores:
                flag = ' ⚠️ NA' if str(s.score).upper() in ('', 'NA') else ''
                print(f'  [{s.rubric_item_id}] score={s.score}{flag} | {(s.rationale or "")[:120]}')
            print('='*60)

            all_scores[jid] = judge_scores
            append_judgment_recorded(log, question.id, rubric.id, jid,
                                     [s.id for s in judge_scores])

            jr = JudgeResult(
                judge_id=jid, aggregate_score=agg,
                scores=[{'item_id': s.rubric_item_id, 'score': s.score,
                         'rationale': s.rationale} for s in judge_scores],
                raw_response=raw, latency_ms=lat,
            )
            judge_results.append(jr)
            self.metrics.record_eval(
                question_id=question.id, rubric_id=rubric.id,
                rubric_name=rubric.name, judge_id=jid,
                aggregate_score=agg, rationales=rationales,
                latency_ms=lat, status='ok',
            )

        # Pairwise agreement
        judge_ids = list(all_scores.keys())
        pairwise: Dict[Tuple[str, str], float] = {}
        for ja, jb in combinations(judge_ids, 2):
            sc = parser.calculate_pairwise_agreement(all_scores[ja], all_scores[jb])
            pairwise[(ja, jb)] = sc
            pairwise[(jb, ja)] = sc

        agreement_class, outlier = classify_panel_agreement(
            pairwise, judge_ids, self.AGREEMENT_THRESHOLD)
        summary = summarize_agreement(pairwise, judge_ids, self.AGREEMENT_THRESHOLD)
        mean_pw = summary['mean_pairwise_agreement']

        append_agreement_classified(log, question.id, rubric.id,
                                    agreement_class, outlier, mean_pw)
        self.store.put(question.id, log)
        self.metrics.record_agreement(
            question_id=question.id, rubric_id=rubric.id,
            judge_a=judge_ids[0] if judge_ids else '',
            judge_b=judge_ids[1] if len(judge_ids) > 1 else '',
            agreement_score=mean_pw, agreement_class=agreement_class,
        )

        if outlier:
            print(f'\n⚠️  OUTLIER JUDGE: {outlier}')
            for jr in judge_results:
                if jr.judge_id == outlier:
                    print(f'   Score: {jr.aggregate_score:.2f}')
                    for s in jr.scores:
                        print(f'   [{s["item_id"]}] {(s["rationale"] or "")[:120]}')

        # Warn if config max_tokens differs from adapter values
        config_max = self.config.get('max_tokens')
        if config_max:
            for judge in active_judges:
                adapter_max = get_adapter(judge['id']).MAX_NEW_TOKENS
                if adapter_max != config_max:
                    logger.warning(
                        f'Judge {judge["id"]}: config max_tokens={config_max} '
                        f'ignored — adapter MAX_NEW_TOKENS={adapter_max} used instead'
                    )

        return PanelResult(
            question_id=question.id, question_text=question.text,
            question_category=question.category or 'unknown',
            rubric_id=rubric.id, rubric_name=rubric.name,
            rubric_source_paper=rubric.source_paper,
            judge_results=judge_results, agreement_summary=summary,
            agreement_class=agreement_class, outlier_judge=outlier,
            mean_pairwise_agreement=mean_pw, events_jsonl=log.to_jsonl(),
            skipped=False,
        )
